/**
 * Some global objects for addon client (UI).
 */

// To perserve all possible client forms
var ClientForms = {

};
