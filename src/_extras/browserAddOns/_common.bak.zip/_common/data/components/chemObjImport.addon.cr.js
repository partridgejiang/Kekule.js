/**
 * Specified code related to Chrome addon.
 */
