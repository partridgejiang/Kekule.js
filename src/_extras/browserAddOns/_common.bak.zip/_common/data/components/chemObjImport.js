(function()
{
/**
 * JS object corresponding to chemObjImport.html
 * @object
 */
var FormChemObjImport = {
	idChemObjInserter: 'chemObjInserter',
	idButtonPanel: 'buttonPanel',
	idButtonOk: 'btnOk',
	idButtonCancel: 'btnCancel',
	idContainer: 'container',
	panelExtraPadding: 10,

	// a special mark, whether the panel currently is used to modify an existing chem obj element
	isModify: false,

	getChemObjInserter: function()
	{
		return Kekule.Widget.getWidgetById(F.idChemObjInserter);
	},
	getChemViewer: function()
	{
		return F.getChemObjInserter().getViewer();
	},
	// Whether current 3D tab selected
	isActiveOn3D: function()
	{
		return F.getChemObjInserter().getIs3D();
	},

	getButtonPanel: function()
	{
		return Kekule.Widget.getWidgetById(F.idButtonPanel);
	},
	getContainerElem: function()
	{
		return document.getElementById(F.idContainer);
	},

	// Create a new element to display current chem object
	createInsertTargetElem: function(doc)
	{
		var objSetter = F.getChemObjInserter();
		return objSetter.createExportImgElement(doc);
	},

	loadChemObjElemAttribs: function(attribs)
	{
		var inserter = F.getChemObjInserter();
		//console.log('receive response', attribs);
		if (attribs)
		{
			F.isModify = true;
			inserter.importFromElemAttribs(attribs);
		}
		else  //
			F.isModify = false;
		// If no curr selected chemObj, retain last one in viewer
		/*
		else
			inserter.setChemObj(null);
		*/
	},

	//
	submit: function()
	{
		F.AddonImpl.submit();
	},
	cancel: function()
	{
		F.AddonImpl.cancel();
	},

	// resize inserter widget
	resizeWidget: function(size)
	{
		if (size && size.width && size.height)
			F.getChemObjInserter().setContextDimension(size);
	},
	// calc the proper size for view to contain all widgets
	getMinContainerSize: function()
	{
		var padding = Kekule.StyleUtils.getComputedStyle(document.body, 'padding-left');
		var pvalue = Kekule.StyleUtils.analysisUnitsValue(padding);
		padding = (pvalue.value || 0); // * 2;
		//console.log(padding);
		padding += F.panelExtraPadding;
		/*
		var dimBtnPanel = F.getButtonPanel().getDimension();
		var dimInserter = F.getChemObjInserter().getDimension();
		return {'width': dimInserter.width + padding, 'height': dimBtnPanel.bottom + padding};
		*/
		var dim = Kekule.HtmlElementUtils.getElemBoundingClientRect(F.getContainerElem());
		return {'width': dim.right + padding, 'height': dim.bottom + padding};
	},
	// send message to tell resize container panel to fit widget size
	requestResizeContainer: function(forceResize)
	{
		F.AddonImpl.requestResizeContainer(forceResize);
	},

	// auto size form, fit the view
	fitContainerView: function()
	{
		var dim = Kekule.HtmlElementUtils.getViewportDimension(document);
		F.getChemObjInserter().setDimension(dim.width, dim.height - 40);
		//console.log('fit view', dim);
	},
	// if not editable in content page, show warning information
	displayContentEditableInfo: function(editable)
	{
		var s = editable? '': Kekule.$L('BrowserAddonTexts.LABEL_TARGET_NOT_EDITABLE');
		var sclass = editable? 'Hidden': 'Warning';
		var elem = document.getElementById('info');
		elem.innerHTML = s;
		elem.className = sclass;
	},

	_init: function()
	{
		/*
		console.log('init');
		F.fitContainerView();
		*/
		F._initEventListeners();
		F.getChemObjInserter().addEventListener('resize', function(e) { F.requestResizeContainer(); });
		Kekule.Widget.getWidgetById(F.idButtonOk).setText(Kekule.$L('WidgetTexts.CAPTION_OK')).addEventListener('execute', F.submit);
		Kekule.Widget.getWidgetById(F.idButtonCancel).setText(Kekule.$L('WidgetTexts.CAPTION_CANCEL')).addEventListener('execute', F.cancel);
	},

	_initEventListeners: function()
	{
		F.AddonImpl._initEventListeners();
	}
};
var F = FormChemObjImport;
ClientForms.FormChemObjImport = F;

Kekule.X.domReady(FormChemObjImport._init);


})();