(function(){

"use strict";

////////////////////////////////////////////////
// code for RXN I/O
////////////////////////////////////////////////

// predefined rxn formats
var fmtRxn = 'rxn';
var fmtRxn3k = 'rxn3k';

// create new RXN writer, write chem document into reaction
var MyChemDocToMdlRxnWriter = Class.create(Kekule.IO.ChemDataWriter,
    {
        /** @private */
        CLASS_NAME: 'MyChemDocToMdlRxnWriter',
        /** @private */
        doWriteData: function($super, obj, dataType, format)
        {
            var dtype = dataType || Kekule.IO.ChemDataType.TEXT;
            if (dtype != Kekule.IO.ChemDataType.TEXT) // can not understand data other than text
            {
                Kekule.error(Kekule.$L('ErrorMsg.MDL_OUTPUT_DATATYPE_NOT_TEXT'));
                return null;
            }
            else
            {
                var options = {
                    'mdlVersion': (format === Kekule.IO.DataFormat.RXN3K)? Kekule.IO.MdlVersion.V3000: Kekule.IO.MdlVersion.V2000
                };
                var rxnWriter = new Kekule.IO.MdlRxnWriter(options);  // use existing rxn writer to save data
                if (obj instanceof Kekule.Reaction)  // obj is an instance of reaction, output it directly
                {
                    return rxnWriter.writeData(obj, dataType, format);
                }
                else if (obj instanceof Kekule.ChemSpace)  // chemspace is the ancestor of chem document, convert it to reaction first then save
                {
                    var reaction = this._convertChemSpaceToReaction(obj);
                    return rxnWriter.writeData(reaction, dataType, format);
                }
                else
                    return null;
            }
        },

        /** @private */
        _convertChemSpaceToReaction: function(chemSpace)
        {
            var arrows = [];
            var molecules = [];
            // iterate all child objects, extract arrows and molecules
            for (var i = 0, l = chemSpace.getChildCount(); i < l; ++i)
            {
                var child = chemSpace.getChildAt(i);
                if (child instanceof Kekule.Glyph.StraightLine)
                    arrows.push(child);
                else if (child instanceof Kekule.Molecule)
                    molecules.push(child);
            }

            if (!arrows.length)
            {
                Kekule.error('Reaction arrow not found, not a valid reaction.');
                return null;
            }
            else if (arrows.length > 1)
            {
                Kekule.error('Too many reaction arrows.');
                return null;
            }
            else  // one arrow, generate reaction
            {
                var arrow = arrows[0];
                var arrowBox = arrow.getContainerBox();

                var reactants = [], products = [], substances = [];
                molecules.forEach(function(molecule){
                    var molBox = molecule.getContainerBox();
                    if (molBox.x2 < arrowBox.x1)  // molecule at left side of arrow, reactant
                        reactants.push(molecule);
                    else if (molBox.x1 > arrowBox.x2)  // molecule at right side of arrow, product
                        products.push(molecule);
                    else  // molecule above or below arrow, substance
                        substances.push(molecule);
                });

                if (!reactants.length || !products.length)
                {
                    Kekule.error('Not enough reactants or products');
                    return null;
                }
                else
                {
                    // sort reagents
                    var sortMolFunc = function(mol1, mol2)
                    {
                        var molBox1 = mol1.getContainerBox();
                        var molBox2 = mol2.getContainerBox();
                        var molCenter1 = Kekule.BoxUtils.getCenterCoord(molBox1);
                        var molCenter2 = Kekule.BoxUtils.getCenterCoord(molBox2);
                        return molCenter1.x - molCenter2.x;
                    };
                    reactants.sort(sortMolFunc);
                    products.sort(sortMolFunc);
                    substances.sort(sortMolFunc);

                    // create reaction
                    var result = new Kekule.Reaction();
                    reactants.forEach(function(mol){
                        result.appendReactant(mol);
                    });
                    products.forEach(function(mol){
                        result.appendProduct(mol);
                    });
                    substances.forEach(function(mol){
                        result.appendSubstance(mol);
                    });
                    return result;
                }
            }
        }
    });
// register our new RXN writer on ChemSpace class
Kekule.IO.ChemDataWriterManager.register('chemspace-MDL-rxn', MyChemDocToMdlRxnWriter, [Kekule.ChemSpace], [Kekule.IO.DataFormat.RXN, Kekule.IO.DataFormat.RXN3K]);

// create new RXN reader, read RXN format data and returns a chem document
var MyMdlRxnToChemDocReader = Class.create(Kekule.IO.ChemDataReader,
    {
        /** @private */
        CLASS_NAME: 'MyMdlRxnToChemDocReader',
        /** @private */
        doReadData: function(data, dataType, format)
        {
            if (dataType != Kekule.IO.ChemDataType.TEXT) // can not understand data other than text
            {
                Kekule.error(Kekule.$L('ErrorMsg.MDL_INPUT_DATATYPE_NOT_TEXT'));
                return null;
            }
            else
            {
                // use Kekule.IO.MdlRxnReader to load data into a Reaction instance first
                var rxnReader = new Kekule.IO.MdlRxnReader();
                var reaction = rxnReader.readData(data, Kekule.IO.ChemDataType.TEXT);
                if (reaction)  // reaction loaded successful, then convert it into chem document
                {
                    var result = this._convertReactionToChemDocument(reaction);
                    return result;
                }
                else
                    return null;
            }
        },
        /** @private */
        _convertReactionToChemDocument: function(reaction)
        {
            var chemdoc = this._createChemDocument();

            var refLength = chemdoc.getDefAutoScaleRefLength();  // reference length of document
            var padding = refLength;  // / 2;  // padding between molecules and arrow/plus symbol

            var reactionObjs = [];
            // reactants and plus symbols
            for (var i = 0, l = reaction.getReactantCount(); i < l; ++i)
            {
                var reactant = reaction.getReactantAt(i);
                if (i > 0)
                {
                    reactionObjs.push(new Kekule.Glyph.AddSymbol(null, refLength, {
                        // 'lineLength': 1.5   // use a larger plus symbol, 1.5 times larger than the default one
                    }));
                }
                reactionObjs.push(reactant);
            }

            // reaction arrow
            var arrow = new Kekule.Glyph.StraightLine(null, refLength, {
                'endArrowType': Kekule.Glyph.ArrowType.OPEN,
                'endArrowWidth': 0.25,
                'endArrowLength': 0.25,
                'startArrowType': Kekule.Glyph.ArrowType.NONE,
                'lineLength': 1.5
            });
            reactionObjs.push(arrow);

            // products and plus symbols
            for (var i = 0, l = reaction.getProductCount(); i < l; ++i)
            {
                var product = reaction.getProductAt(i);
                if (i > 0)
                    reactionObjs.push(new Kekule.Glyph.AddSymbol(null, refLength));
                reactionObjs.push(product);
            }

            chemdoc.beginUpdate();
            try
            {
                var totalDim = {x: 0, y: 0};   // stores the total dimension of the whole reaction
                var containerBoxes = [];
                // add objs to chem doc
                // and get container box of each objects
                reactionObjs.forEach(function(obj)
                {
                    chemdoc.appendChild(obj);
                    obj.setCoord2D({'x': 0, 'y': 0});  // set an initial coord of each object
                    var containerBox = obj.getContainerBox();
                    if (containerBox.y2 - containerBox.y1 > totalDim.y)
                        totalDim.y = containerBox.y2 - containerBox.y1;   // height of the total dimension, largest height of all container boxes
                    totalDim.x += (containerBox.x2 - containerBox.x1);  // width of the total dimension, sum of widths of container boxes
                    containerBoxes.push(containerBox);
                });
                totalDim.x += padding * (reactionObjs.length - 1);  // width of the total dimension, plus all paddings between objects

                // adjust chem document size
                var paddedTotalDim = {x: totalDim.x + padding * 2, y: totalDim.y + padding * 2};
                this._adjustChemDocumentSize(chemdoc, paddedTotalDim);

                // adjust coord 2d of each objects
                var docDim = chemdoc.getSize2D();   // dimension of the chem document box
                var currLeft = (docDim.x - totalDim.x) / 2;   // left edge of reaction in document box
                var yCoord = (docDim.y - totalDim.y / 2) - padding;  // center y coord of reaction
                for (var i = 0, l = reactionObjs.length; i < l; ++i)
                {
                    var obj = reactionObjs[i];
                    var box = containerBoxes[i];
                    var boxWidth = box.x2 - box.x1;
                    var boxHeight = box.y2 - box.y1;
                    var delta = {     // coord to be adjusted to current object
                        'x': currLeft - box.x1,
                        'y': yCoord - box.y1 - boxHeight / 2
                    };
                    var oldCoord = obj.getCoord2D();
                    obj.setCoord2D({
                        'x': oldCoord.x + delta.x,
                        'y': oldCoord.y + delta.y
                    });
                    currLeft += boxWidth  + padding;
                }
            }
            finally
            {
                chemdoc.endUpdate();
            }
            return chemdoc;
        },
        /** @private */
        _createChemDocument: function()
        {
            var chemDoc = new Kekule.ChemDocument();
            // the chem doc settings are borrowed from the default editor configs
            var editorConfigs = Kekule.Editor.ChemSpaceEditorConfigs.getInstance();
            var renderConfigs = Kekule.Render.Render2DConfigs.getInstance();
            var screenSize = editorConfigs.getChemSpaceConfigs().getDefScreenSize2D();
            var objRefLength = editorConfigs.getStructureConfigs().getDefBondLength();
            var screenRefLength = renderConfigs.getLengthConfigs().getDefBondLength();
            var ratio = objRefLength / screenRefLength;
            chemDoc.setDefAutoScaleRefLength(objRefLength);
            chemDoc.setObjScreenLengthRatio(ratio);
            chemDoc.setSize2D({'x': screenSize.x * ratio, 'y': screenSize.y * ratio});
            return chemDoc;
        },
        /** @private */
        _adjustChemDocumentSize: function(chemDoc, reactionDim)
        {
            var currSize = chemDoc.getSize2D();
            var newSize = {'x': currSize.x, 'y': currSize.y};
            if (currSize.x < reactionDim.x)
            {
                newSize.x = reactionDim.x;
            }
            if (currSize.y < reactionDim.y)
            {
                newSize.y = reactionDim.y;
            }
            var ratio = chemDoc.getObjScreenLengthRatio();
            chemDoc.setSize2D(newSize);
            chemDoc.setScreenSize({'x': newSize.x / ratio, 'y': newSize.y / ratio});
        }
    });
// register our rxn reader, overwrite the existing one
Kekule.IO.ChemDataReaderManager.register('chemspace-MDL-rxn', MyMdlRxnToChemDocReader, [Kekule.IO.DataFormat.RXN, Kekule.IO.DataFormat.RXN3K]);


})();

